package Irctc.Book;

import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Objects {

	static WebDriverWait wait;
	static ProfilesIni profile = new ProfilesIni();
	static FirefoxProfile myprofile = profile.getProfile("seleniumprofile");
	static WebDriver driver = new FirefoxDriver(myprofile);
	static Properties p = new Properties();
	String Actualtext;
	static Form form = new Form();
	static Method object = new Method();
	static Method log = new Method();

}
