package Irctc.Book;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

public class Form extends Method {

	String Actualtext;
	List<WebElement> e1 = null;

	public void Launch1() throws InterruptedException, IOException {
		maximize();
		data();
		driver.get(p.getProperty("baseurl"));
		driver.findElement(By.cssSelector("#demon_content>div>input")).click();
	}

	public void Login1() throws Exception {
		driver.findElement(By.cssSelector("#usernameId")).sendKeys(p.getProperty("username"));
		driver.findElement(By.cssSelector(".loginPassword")).sendKeys(p.getProperty("password"));
		hardwait(10);
		driver.findElement(By.cssSelector("#loginbutton")).click();
		do {
			e1 = driver.findElements(By.xpath("//input[@id='loginerrorpanelok']"));
			if (e1.size() != 0) {
				e1.get(0).click();
				driver.findElement(By.cssSelector("#usernameId")).sendKeys(p.getProperty("username"));
				driver.findElement(By.cssSelector(".loginPassword")).sendKeys(p.getProperty("password"));
				hardwait(8);
				driver.findElement(By.cssSelector("#loginbutton")).click();
			}

		} while (e1.size() != 0);

	}

	public void FindTrain1() throws IOException {
		data();
		e1 = driver.findElements(By.xpath("//input[@value='Continue']"));
		if (e1.size() != 0) {
			e1.get(0).click();
		}
		driver.findElement(By.xpath("//input[@id='jpform:fromStation']")).sendKeys(p.getProperty("from"));
		driver.findElement(By.xpath("//input[@id='jpform:toStation']")).sendKeys(p.getProperty("to"));
		// .findElement(By.xpath("//a[@id='JpSwapFromTo']")).click(); //Swap
		// the route.
		driver.findElement(By.xpath("//input[@id='jpform:journeyDateInputDate']")).sendKeys("14-04-2017");
		driver.findElement(By.xpath("//input[@id='jpform:jpsubmit']")).click();

	}

	public void Availability1() throws Exception {
		time(15);
		driver.findElement(By.xpath("//a[@id='cllink-12451-SL-3']")).click();
		Actualtext = driver.findElement(By.xpath("(.//*[@id='j_idt369_body']/table/tbody/tr[2]/td[2])[2]")).getText();
		System.out.println(Actualtext);
		Assert.assertEquals("AVAILABLE", Actualtext.substring(0, 9));
		driver.findElement(By.xpath("(.//a[@id='12451-SL-GN-0'])[2]")).click();
	}

	public void Pass() throws Exception {
		time(15);
		driver.findElement(By.xpath(" (//input[starts-with(@id,'addPassengerForm:psdetail:0:p')])[1]"))
				.sendKeys(p.getProperty("Passenger1"));
		driver.findElement(By.xpath(" (//input[starts-with(@id,'addPassengerForm:psdetail:1:p')])[1]"))
				.sendKeys(p.getProperty("Passenger2"));
		driver.findElement(By.id("addPassengerForm:psdetail:0:psgnAge")).sendKeys(p.getProperty("Age1"));
		driver.findElement(By.id("addPassengerForm:psdetail:1:psgnAge")).sendKeys(p.getProperty("Age2"));
		driver.findElement(By.xpath(".//select[@id='addPassengerForm:psdetail:0:psgnGender']//option[@value='M']")) // Male

				.click();
		driver.findElement(By.xpath(".//select[@id='addPassengerForm:psdetail:1:psgnGender']//option[@value='F']")) // Female

				.click();
		driver.findElement(By.xpath(".//select[@id='addPassengerForm:psdetail:0:berthChoice']//option[@value='SL']")) // Side
																														// Lower
				.click();
		driver.findElement(By.xpath(".//select[@id='addPassengerForm:psdetail:1:berthChoice']//option[@value='SU']")) // Side
																														// Uper
				.click();
		driver.findElement(By.id("addPassengerForm:autoUpgrade")).click();
		driver.findElement(By.id("addPassengerForm:onlyConfirmBerths")).click();
		driver.findElement(By.id("addPassengerForm:mobileNo")).clear();
		driver.findElement(By.id("addPassengerForm:mobileNo")).sendKeys(p.getProperty("MobileNo"));
		switchToFrame("html5Captcha");
		driver.findElement(By.id("Stage_BOX2")).click();
		switchToDefaultContent();
		driver.findElement(By.id("validate")).click();
	}

	public void Payment1() {
		time(5);
		driver.findElement(By.xpath("//label[contains(text(),'Cash Card / Wallets')]")).click();
		driver.findElement(By.xpath("(//input[@id='CASH_CARD'])[6]")).click();
		driver.findElement(By.id("validate")).click();

	}

	public void Paytm1() throws InterruptedException {

		Actualtext = driver.findElement(By.xpath("(//div[@class='mb10'])[4]")).getText();
		System.out.println(Actualtext);
		hardwait(3);
		driver.findElement(By.id("otp-btn")).click();
		driver.switchTo().frame("login-iframe");
		driver.findElement(By.xpath("(//input[@name='username'])[1]")).sendKeys(Method.p.getProperty("MobileNo"));
		driver.findElement(By.xpath("//button[@type='submit']")).click();
	}
}
