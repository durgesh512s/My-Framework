package Irctc.Book;

import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Objects {

	static WebDriverWait wait;
	protected static WebDriver driver = new FirefoxDriver();
	static Properties p = new Properties();
	String Actualtext;
	static Form form = new Form();
	static Method object = new Method();
	static Method log = new Method();

}
