package Irctc.Book;

public enum Locators {
	id, name, classname, css, xpath, linktext;
}

